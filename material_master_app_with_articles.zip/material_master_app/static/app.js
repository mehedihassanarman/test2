const $=s=>document.querySelector(s);let mode='new';let tasks=[];
const field=(name,label,type='text')=>`<label class="field">${label}<input name="${name}" type="${type}" required></label>`;
const select=(name,label,options)=>`<label class="field">${label}<select name="${name}" required>${options.map(o=>`<option value="${o}">${o}</option>`).join('')}</select></label>`;
function openModal(next){
 mode=next;$('#entryForm').reset();$('#message').textContent='';
 $('#modalTitle').textContent=mode==='new'?'New Material':mode==='extension'?'Material Extension':'Article Creation';
 $('#formFields').innerHTML=mode==='new'
  ?field('code','Material Code')+field('name','Material Description')+select('material_type','Material Type',['ROH','FERT','HALB','HIBE'])+select('unit','Base Unit',['EA','KG','L','M'])+field('plant','Plant')+field('subsidiary','Source Subsidiary')
  :mode==='extension'
  ?field('material_code','Existing Material Code')+field('plant','Extension Plant')+field('subsidiary','Target Subsidiary')
  :'<p>A unique 6-digit article code will be generated automatically.</p>'+field('description','Article Description')+select('category','Article Category',['Raw Material','Finished Goods','Semi-Finished','Other'])+select('unit','Base Unit',['EA','KG','L','M'])+field('subsidiary','Source Subsidiary');
 $('#modal').showModal();
}
document.querySelectorAll('[data-modal]').forEach(b=>b.onclick=()=>openModal(b.dataset.modal));$('#close').onclick=$('#cancel').onclick=()=>$('#modal').close();
document.querySelectorAll('[data-toggle]').forEach(h=>h.onclick=()=>{const el=document.getElementById(h.dataset.toggle);el.hidden=!el.hidden;h.querySelector('span').textContent=el.hidden?'⌄':'⌃'});
async function api(url,options){const res=await fetch(url,options);const data=await res.json();if(!res.ok)throw new Error(data.error||'Request failed');return data}
$('#entryForm').onsubmit=async e=>{e.preventDefault();const data=Object.fromEntries(new FormData(e.target));try{const result=await api(mode==='new'?'/api/materials':mode==='extension'?'/api/extensions':'/api/articles',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});$('#modal').close();await loadTasks();alert(result.article_code?`${result.message}\nGenerated article code: ${result.article_code}`:result.message)}catch(err){$('#message').textContent=err.message}};
function render(){const q=$('#search').value.toLowerCase().trim(),filter=$('#filter').value;const filtered=tasks.filter(t=>(filter==='all'||t.status===filter)&&Object.values(t).some(v=>String(v).toLowerCase().includes(q)));const body=$('#taskRows');body.replaceChildren();if(!filtered.length){const tr=document.createElement('tr'),td=document.createElement('td');td.colSpan=8;td.className='empty';td.textContent='No items to display';tr.append(td);body.append(tr);return}for(const t of filtered){const tr=document.createElement('tr');const cells=[t.process_name,t.task_name,String(t.id),t.subsidiary,t.material_code,t.initiator,t.start_date];for(const value of cells){const td=document.createElement('td');td.textContent=value;tr.append(td)}const td=document.createElement('td');td.className='task-actions';const status=document.createElement('span');status.className='status '+t.status;status.textContent=t.status;td.append(status);if(t.status==='Open'){for(const [label,next] of [['Approve','Approved'],['Reject','Rejected']]){const b=document.createElement('button');b.textContent=label;b.onclick=()=>updateTask(t.id,next);td.append(b)}}tr.append(td);body.append(tr)}}
async function updateTask(id,status){try{await api(`/api/tasks/${id}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({status})});await loadTasks()}catch(e){alert(e.message)}}
async function loadTasks(){try{tasks=await api('/api/tasks');render()}catch(e){console.error(e);alert('Could not load tasks.')}}
$('#filter').onchange=render;$('#search').oninput=render;$('#refresh').onclick=loadTasks;loadTasks();
