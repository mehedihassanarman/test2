# Material Master Data Management

A responsive Flask dashboard inspired by the supplied screenshot. It includes New Material, Material Extension, task search/filter, and approval/rejection. Data persists in SQLite (`materials.db`, created on first run).

## Run

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:5000

## Project structure
- `app.py` — Flask server, SQLite models and JSON API
- `templates/index.html` — dashboard
- `static/style.css` — screenshot-inspired styling
- `static/app.js` — UI and API integration

## API
- `GET /api/materials`
- `POST /api/materials`
- `POST /api/extensions`
- `GET /api/tasks`
- `PATCH /api/tasks/<id>` with `{"status":"Approved"}` or `{"status":"Rejected"}`

This is a local demo, not a production authentication/authorization system. Replace the placeholder support email before deployment. Disable Flask debug mode and add authentication, CSRF protection, and access controls for production.

## Article Creation
Click the blue Article Creation tile, enter the required details, and submit. The server allocates a unique six-digit article code beginning at 100001, stores it in the `articles` SQLite table, and adds an Open task to My Tasks. The generated code is shown after submission. View saved articles via `GET /api/articles`.
