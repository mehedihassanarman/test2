# Material Master Data Management

A responsive Flask dashboard inspired by the supplied screenshot. It includes New Material, Material Extension, task search/filter, and approval/rejection. Data persists in SQLite (`materials.db`, created on first run).

## Run

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:5000

## Project structure
- `app.py` — Flask server, SQLite models and JSON API
- `templates/index.html` — dashboard
- `static/style.css` — screenshot-inspired styling
- `static/app.js` — UI and API integration

## API
- `GET /api/materials`
- `POST /api/materials`
- `POST /api/extensions`
- `GET /api/tasks`
- `PATCH /api/tasks/<id>` with `{"status":"Approved"}` or `{"status":"Rejected"}`

This is a local demo, not a production authentication/authorization system. Replace the placeholder support email before deployment. Disable Flask debug mode and add authentication, CSRF protection, and access controls for production.

## Article Creation
Click the blue Article Creation tile, enter the required details, and submit. The server allocates a unique six-digit article code beginning at 100001, stores it in the `articles` SQLite table, and adds an Open task to My Tasks. The generated code is shown after submission. View saved articles via `GET /api/articles`.

## Article-first material workflow
1. Open **New Material** and answer **Does an approved 6-digit article exist?**
2. **No** opens Article Creation to submit a request; a six-digit code is reserved and an Open approval task is created.
3. Approve the Article Creation task in **My Tasks** (demo approval only; no authentication).
4. Reopen **New Material**, choose **Yes**, select the approved article code and complete the material fields.
5. The server rejects attempts to create a material using an unapproved or unknown article code.

Existing SQLite databases are migrated automatically with a new nullable `materials.article_code` column. Previously created materials remain unchanged. The demonstration task approval is not suitable for production without user authentication and authorization.


## Article notification handoff
In New Material choose **No**, provide a description, subsidiary and requester, then Submit Request. This creates a pending notification in the Article Notifications section; it does **not** automatically create an article. In Article Creation select the pending notification, complete its details and submit. Approve the resulting Article Creation task in My Tasks. Its notification becomes **Ready for Material**, and a **Create New Material** action preselects the approved article. Rejected articles cannot be used.

This is an in-app notification workflow (not email or push notifications). The demo has no authentication or role permissions.


## Role-based access (demo)

Log in as `material`, `article`, or `approver`, each with initial password `ChangeMe123!` (override with environment variable `DEMO_PASSWORD` **before the first startup**). Set a persistent random `FLASK_SECRET_KEY` for deployments. Each role sees its permitted process buttons; only approvers can approve/reject tasks. Material users see their own article notifications, while Article Creation users see the incoming requests.

**Important:** This is a local demo, not production-ready identity management. Replace seeded credentials, enforce HTTPS, CSRF protection, proper user administration, and secure session settings before deployment.

### Material Extension dropdown
The Material Extension form loads existing material numbers and descriptions from `GET /api/materials`. Select a material before entering the target plant and subsidiary. The backend validates the material number and rejects duplicate extensions.


## Added Admin User Management

The original application workflows and existing user accounts remain intact. An admin-only panel now supports listing, adding, editing, and deleting users, including their full names, usernames, roles, and passwords. Existing SQLite databases are migrated automatically by adding `full_name`. Passwords are hashed; a blank password when editing keeps the existing one. Admin APIs enforce authorization on the server, prevent deleting your own account, and protect the last administrator.

To create the initial administrator, set environment variable `ADMIN_PASSWORD` to a strong unique password (at least 12 characters recommended) before starting the app. Optionally set `ADMIN_USERNAME` (default: `admin`). Example on macOS/Linux:

```bash
export ADMIN_USERNAME=admin
export ADMIN_PASSWORD='replace-with-a-long-unique-password'
python app.py
```

Windows PowerShell:

```powershell
$env:ADMIN_USERNAME='admin'
$env:ADMIN_PASSWORD='replace-with-a-long-unique-password'
python app.py
```

Once the administrator has been created, it remains in the database for subsequent runs. No default admin password is shipped. For production, set `FLASK_SECRET_KEY` to a stable secret, disable Flask debug mode, use HTTPS and secure session cookies, and implement CSRF protection and login rate limiting.
