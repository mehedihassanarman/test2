let activeUser=null;
const $=s=>document.querySelector(s);let mode='new';let tasks=[];let notifications=[];
const field=(name,label,type='text')=>`<label class="field">${label}<input name="${name}" type="${type}" required></label>`;
const select=(name,label,options)=>`<label class="field">${label}<select name="${name}" required>${options.map(o=>`<option value="${o}">${o}</option>`).join('')}</select></label>`;
const escapeHtml=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
async function openModal(next){
 mode=next;$('#entryForm').reset();$('#message').textContent='';
 $('#modalTitle').textContent=mode==='new'?'New Material':mode==='extension'?'Material Extension':'Article Creation';
 if(mode==='new'){
   $('#formFields').innerHTML=`<label class="field">Does an approved 6-digit article exist?<select id="articleExists" required><option value="">Choose...</option><option value="yes">Yes</option><option value="no">No — request Article Creation</option></select></label><div id="articleChoice"></div><div id="materialFields" hidden>${field('code','Material Code')+field('name','Material Description')+select('material_type','Material Type',['ROH','FERT','HALB','HIBE'])+select('unit','Base Unit',['EA','KG','L','M'])+field('plant','Plant')+field('subsidiary','Source Subsidiary')}</div>`;
   $('#articleExists').onchange=async()=>{
     const yes=$('#articleExists').value==='yes',no=$('#articleExists').value==='no';
     $('#materialFields').hidden=!yes;
     $('#materialFields').querySelectorAll('input,select').forEach(el=>el.disabled=!yes);
     if(no){$('#articleChoice').innerHTML=`<p>This sends a notification to the Article Creation team. You will receive a confirmation in New Material when the article is approved.</p>${field('description','Requested Article Description')}${field('subsidiary','Source Subsidiary')}`;}
     else if(yes){$('#articleChoice').innerHTML='<label class="field">Approved 6-digit Article<select name="article_code" id="articleCode" required><option value="">Loading approved articles...</option></select></label>';try{const articles=await api('/api/articles/approved');$('#articleCode').innerHTML='<option value="">Select an approved article...</option>'+articles.map(a=>`<option value="${escapeHtml(a.code)}">${escapeHtml(a.code)} — ${escapeHtml(a.description)}</option>`).join('');if(!articles.length)$('#message').textContent='No approved articles yet. Choose No to request Article Creation.';}catch(e){$('#message').textContent=e.message;}}
     else $('#articleChoice').innerHTML='';
   };
   $('#materialFields').querySelectorAll('input,select').forEach(el=>el.disabled=true);
 }else if(mode==='extension'){
   $('#formFields').innerHTML='<label class="field">Existing Material Number<select name="material_code" id="extensionMaterial" required><option value="">Loading materials...</option></select></label>'+field('plant','Extension Plant')+field('subsidiary','Target Subsidiary');
   try{
     const materials=await api('/api/materials');
     $('#extensionMaterial').innerHTML='<option value="">Select existing material...</option>'+materials.map(m=>`<option value="${escapeHtml(m.code)}">${escapeHtml(m.code)} — ${escapeHtml(m.name)}</option>`).join('');
     if(!materials.length)$('#message').textContent='No materials found. Create a new material first.';
   }catch(err){$('#extensionMaterial').innerHTML='<option value="">Unable to load materials</option>';$('#message').textContent=err.message;}
 }
 else $('#formFields').innerHTML='<div id="articleNotificationPicker"></div><p>A unique 6-digit article code will be reserved. It becomes available for New Material only after its task is approved.</p>'+field('description','Article Description')+select('category','Article Category',['Raw Material','Finished Goods','Semi-Finished','Other'])+select('unit','Base Unit',['EA','KG','L','M'])+field('subsidiary','Source Subsidiary');
 if(mode==='article'){await loadNotifications();const pending=notifications.filter(n=>n.status==='Pending');$('#articleNotificationPicker').innerHTML='<label class="field">Pending New Material notifications<select name="notification_id" id="notificationId"><option value="">Direct article request (no notification)</option>'+pending.map(n=>`<option value="${n.id}">#${n.id} — ${escapeHtml(n.description)} (${escapeHtml(n.subsidiary)})</option>`).join('')+'</select></label>';$('#notificationId').onchange=()=>{const n=pending.find(n=>String(n.id)===$('#notificationId').value);if(n){for(const k of ['description','subsidiary'])$('#entryForm').elements[k].value=n[k]}};}
 $('#modal').showModal();
}
document.querySelectorAll('[data-modal]').forEach(b=>b.onclick=()=>openModal(b.dataset.modal));$('#close').onclick=$('#cancel').onclick=()=>$('#modal').close();
document.querySelectorAll('[data-toggle]').forEach(h=>h.onclick=()=>{const el=document.getElementById(h.dataset.toggle);el.hidden=!el.hidden;h.querySelector('span').textContent=el.hidden?'⌄':'⌃'});
async function api(url,options){const res=await fetch(url,options);const data=await res.json();if(!res.ok)throw new Error(data.error||'Request failed');return data}
$('#entryForm').onsubmit=async e=>{e.preventDefault();const data=Object.fromEntries(new FormData(e.target));if(mode==='new'&&$('#articleExists').value==='no'){try{const result=await api('/api/article-notifications',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});$('#modal').close();await loadNotifications();alert(result.message)}catch(err){$('#message').textContent=err.message}return;}if(mode==='new'&&$('#articleExists').value!=='yes'){$('#message').textContent='Choose whether the article exists.';return;}try{const result=await api(mode==='new'?'/api/materials':mode==='extension'?'/api/extensions':'/api/articles',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});$('#modal').close();await loadTasks();await loadNotifications();alert(result.article_code?`${result.message}\nGenerated article code: ${result.article_code}`:result.message)}catch(err){$('#message').textContent=err.message}};
function render(){const q=$('#search').value.toLowerCase().trim(),filter=$('#filter').value;const filtered=tasks.filter(t=>(filter==='all'||t.status===filter)&&Object.values(t).some(v=>String(v).toLowerCase().includes(q)));const body=$('#taskRows');body.replaceChildren();if(!filtered.length){const tr=document.createElement('tr'),td=document.createElement('td');td.colSpan=8;td.className='empty';td.textContent='No items to display';tr.append(td);body.append(tr);return}for(const t of filtered){const tr=document.createElement('tr');const cells=[t.process_name,t.task_name,String(t.id),t.subsidiary,t.material_code,t.initiator,t.start_date];for(const value of cells){const td=document.createElement('td');td.textContent=value;tr.append(td)}const td=document.createElement('td');td.className='task-actions';const status=document.createElement('span');status.className='status '+t.status;status.textContent=t.status;td.append(status);if(t.status==='Waiting for Sales Org Data' && activeUser?.role==='sales_org'){const b=document.createElement('button');b.textContent='New Material';b.onclick=()=>openSalesRequest(t.id);td.append(b)}if(t.status==='Open' && activeUser?.role==='approver'){const b=document.createElement('button');b.textContent='View Details';b.onclick=()=>openApproverRequest(t.id);td.append(b)}tr.append(td);body.append(tr)}}
async function updateTask(id,status){try{await api(`/api/tasks/${id}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({status})});await loadTasks()}catch(e){alert(e.message)}}
async function loadNotifications(){try{notifications=await api('/api/article-notifications');renderNotifications()}catch(e){console.error(e)}}
function renderNotifications(){const ready=notifications.filter(n=>n.status==='Ready for Material');const pending=notifications.filter(n=>n.status==='Pending'||n.status==='In Review');$('#notificationCount').textContent=ready.length?` (${ready.length} ready)`:'';$('#notificationList').replaceChildren();for(const n of notifications){const row=document.createElement('div');row.className='notification-item';const message=document.createElement('span');message.textContent=`#${n.id} · ${n.description} · ${n.status}${n.article_code?' · Article '+n.article_code:''}`;row.append(message);if(n.status==='Ready for Material' && activeUser?.role==='material'){const b=document.createElement('button');b.textContent='Create New Material';b.onclick=async()=>{await openModal('new');$('#articleExists').value='yes';await $('#articleExists').onchange();$('#articleCode').value=n.article_code};row.append(b)}$('#notificationList').append(row)}if(!notifications.length)$('#notificationList').textContent='No article notifications yet.'}
async function loadTasks(){try{tasks=await api('/api/tasks');render()}catch(e){console.error(e);alert('Could not load tasks.')}}
async function showApp(user){activeUser=user;$('#loginScreen').hidden=true;$('#application').hidden=false;$('#userLabel').textContent=(user.full_name||user.username)+' ('+user.role+')';$('#adminPanel').hidden=user.role!=='admin';if(user.role==='admin')await loadAdminUsers();document.querySelectorAll('[data-modal]').forEach(b=>b.hidden=(user.role==='sales_org'||user.role==='approver'||(user.role==='article'&&b.dataset.modal!=='article')||(user.role==='material'&&b.dataset.modal==='article')));if(user.role==='sales_org')document.querySelector('#notificationList').closest('.panel').hidden=true;else document.querySelector('#notificationList').closest('.panel').hidden=false;await Promise.all([loadTasks(),...(user.role==='sales_org'?[]:[loadNotifications()])]);}
$('#loginForm').onsubmit=async e=>{e.preventDefault();const d=Object.fromEntries(new FormData(e.target));try{const u=await api('/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(d)});$('#loginError').textContent='';await showApp(u)}catch(err){$('#loginError').textContent=err.message}};
$('#logout').onclick=async()=>{await api('/api/logout',{method:'POST'});location.reload()};
api('/api/me').then(showApp).catch(()=>{});
$('#filter').onchange=render;$('#search').oninput=render;$('#refresh').onclick=()=>{loadTasks();loadNotifications()};

// Admin-only user management UI
let adminUsers=[], editingUserId=null;
async function loadAdminUsers(){
 try{adminUsers=await api('/api/admin/users');$('#adminError').textContent='';const tbody=$('#adminUserRows');tbody.replaceChildren();
 for(const u of adminUsers){const tr=document.createElement('tr');for(const key of ['full_name','username','role']){const td=document.createElement('td');td.textContent=u[key]||'';tr.append(td)}
 const td=document.createElement('td');for(const action of ['Edit','Delete']){const b=document.createElement('button');b.type='button';b.textContent=action;b.className='admin-action';b.onclick=()=>action==='Edit'?openAdminForm(u):deleteAdminUser(u);td.append(b)}tr.append(td);tbody.append(tr)}
 }catch(e){$('#adminError').textContent=e.message}
}
function openAdminForm(user=null){editingUserId=user?.id??null;$('#adminForm').reset();$('#adminFormTitle').textContent=user?'Edit User':'Add User';$('#adminFormError').textContent='';const f=$('#adminForm').elements;if(user){f.full_name.value=user.full_name;f.username.value=user.username;f.role.value=user.role}f.password.required=!user;$('#adminDialog').showModal()}
async function deleteAdminUser(user){if(!confirm(`Delete user ${user.full_name||user.username} (${user.username})?`))return;try{await api(`/api/admin/users/${user.id}`,{method:'DELETE'});await loadAdminUsers()}catch(e){$('#adminError').textContent=e.message}}
$('#addUser').onclick=()=>openAdminForm();$('#adminClose').onclick=$('#adminCancel').onclick=()=>$('#adminDialog').close();
$('#adminForm').onsubmit=async e=>{e.preventDefault();const data=Object.fromEntries(new FormData(e.target));try{await api(editingUserId===null?'/api/admin/users':`/api/admin/users/${editingUserId}`,{method:editingUserId===null?'POST':'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});$('#adminDialog').close();await loadAdminUsers();if(editingUserId===activeUser?.id){const me=await api('/api/me');activeUser=me;$('#userLabel').textContent=(me.full_name||me.username)+' ('+me.role+')';if(me.role!=='admin')$('#adminPanel').hidden=true}}catch(err){$('#adminFormError').textContent=err.message}};

let salesTaskId=null;
async function openSalesRequest(id){
 try{
  const r=await api(`/api/sales-org/requests/${id}`);salesTaskId=id;
  const labels=[['id','Request #'],['code','Material Code'],['name','Material Description'],['article_code','Article Code'],['material_type','Material Type'],['unit','Base Unit'],['plant','Plant'],['subsidiary','Source Subsidiary'],['initiator','Requested By'],['status','Status']];
  $('#salesRequestDetails').innerHTML=labels.map(([k,label])=>`<p><strong>${label}:</strong> ${escapeHtml(k==='code'?r.material_code:r[k]??'')}</p>`).join('');
  $('#salesForm').reset();$('#salesError').textContent='';$('#salesDialog').showModal();
 }catch(e){alert(e.message)}
}
$('#salesClose').onclick=$('#salesCancel').onclick=()=>$('#salesDialog').close();
$('#salesForm').onsubmit=async e=>{
 e.preventDefault();
 try{const result=await api(`/api/sales-org/requests/${salesTaskId}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(Object.fromEntries(new FormData(e.target)))});
 $('#salesDialog').close();await loadTasks();alert(result.message);
 }catch(err){$('#salesError').textContent=err.message}
};

let approverTaskId=null;
async function openApproverRequest(id){
 try{
  const data=await api(`/api/approver/requests/${id}`);approverTaskId=id;
  const area=$('#approverDetails');area.replaceChildren();
  const sections=[['Request',data.request],...Object.entries(data.details).map(([key,value])=>[key.replace(/_/g,' ').replace(/\b\w/g,c=>c.toUpperCase()),value])];
  for(const [title,values] of sections){
   const section=document.createElement('section');const heading=document.createElement('h3');heading.textContent=title;section.append(heading);
   const records=Array.isArray(values)?values:[values];
   for(const record of records){if(!record)continue;const dl=document.createElement('dl');
    for(const [key,value] of Object.entries(record)){if(key==='password_hash')continue;const dt=document.createElement('dt');dt.textContent=key.replace(/_/g,' ').replace(/\b\w/g,c=>c.toUpperCase());const dd=document.createElement('dd');dd.textContent=value??'—';dl.append(dt,dd)}section.append(dl)}area.append(section);
  }
  $('#approverError').textContent='';$('#approverDialog').showModal();
 }catch(e){alert(e.message)}
}
$('#approverClose').onclick=$('#approverCancel').onclick=()=>$('#approverDialog').close();
async function decideApprover(status){
 if(approverTaskId===null)return;
 const button=$('#approverApprove'),reject=$('#approverReject');button.disabled=reject.disabled=true;
 try{await api(`/api/tasks/${approverTaskId}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({status})});$('#approverDialog').close();approverTaskId=null;await loadTasks()}
 catch(e){$('#approverError').textContent=e.message}
 finally{button.disabled=reject.disabled=false}
}
$('#approverApprove').onclick=()=>decideApprover('Approved');
$('#approverReject').onclick=()=>decideApprover('Rejected');
