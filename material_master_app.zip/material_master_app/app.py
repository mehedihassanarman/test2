from flask import Flask, render_template, request, jsonify
import sqlite3, os
from datetime import datetime
app = Flask(__name__)
DB = os.path.join(os.path.dirname(__file__), 'materials.db')

def connection():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c

def init_db():
    with connection() as c:
        c.execute('CREATE TABLE IF NOT EXISTS materials (id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE NOT NULL, name TEXT NOT NULL, material_type TEXT NOT NULL, unit TEXT NOT NULL, plant TEXT NOT NULL, subsidiary TEXT NOT NULL, created_at TEXT NOT NULL)')
        c.execute('CREATE TABLE IF NOT EXISTS tasks (id INTEGER PRIMARY KEY AUTOINCREMENT, process_name TEXT NOT NULL, task_name TEXT NOT NULL, material_code TEXT NOT NULL, subsidiary TEXT NOT NULL, initiator TEXT NOT NULL, start_date TEXT NOT NULL, status TEXT NOT NULL DEFAULT "Open")')
        c.execute('CREATE TABLE IF NOT EXISTS extensions (id INTEGER PRIMARY KEY AUTOINCREMENT, material_code TEXT NOT NULL, plant TEXT NOT NULL, subsidiary TEXT NOT NULL, created_at TEXT NOT NULL, UNIQUE(material_code, plant, subsidiary))')
init_db()

@app.get('/')
def home(): return render_template('index.html')

@app.get('/api/materials')
def materials():
    with connection() as c: return jsonify([dict(x) for x in c.execute('SELECT * FROM materials ORDER BY id DESC')])

@app.post('/api/materials')
def create_material():
    d=request.get_json(silent=True) or {}
    fields=['code','name','material_type','unit','plant','subsidiary']
    if any(not str(d.get(k,'')).strip() for k in fields): return jsonify(error='All fields are required.'),400
    try:
        with connection() as c:
            c.execute('INSERT INTO materials (code,name,material_type,unit,plant,subsidiary,created_at) VALUES (?,?,?,?,?,?,?)',tuple(str(d[k]).strip() for k in fields)+(datetime.now().isoformat(timespec='seconds'),))
            c.execute('INSERT INTO tasks (process_name,task_name,material_code,subsidiary,initiator,start_date) VALUES (?,?,?,?,?,?)',('New Material','Review new material',d['code'].strip(),d['subsidiary'].strip(),'MDABM Mehedi Hassan',datetime.now().strftime('%Y-%m-%d')))
        return jsonify(message='Material created successfully.'),201
    except sqlite3.IntegrityError: return jsonify(error='Material code already exists.'),409

@app.post('/api/extensions')
def extend_material():
    d=request.get_json(silent=True) or {}
    fields=['material_code','plant','subsidiary']
    if any(not str(d.get(k,'')).strip() for k in fields): return jsonify(error='All fields are required.'),400
    with connection() as c:
        if not c.execute('SELECT 1 FROM materials WHERE code=?',(d['material_code'].strip(),)).fetchone(): return jsonify(error='Material code not found.'),404
        try:
            c.execute('INSERT INTO extensions (material_code,plant,subsidiary,created_at) VALUES (?,?,?,?)',tuple(d[k].strip() for k in fields)+(datetime.now().isoformat(timespec='seconds'),))
            c.execute('INSERT INTO tasks (process_name,task_name,material_code,subsidiary,initiator,start_date) VALUES (?,?,?,?,?,?)',('Material Extension','Review extension',d['material_code'].strip(),d['subsidiary'].strip(),'MDABM Mehedi Hassan',datetime.now().strftime('%Y-%m-%d')))
        except sqlite3.IntegrityError: return jsonify(error='This extension already exists.'),409
    return jsonify(message='Material extension requested.'),201

@app.get('/api/tasks')
def tasks():
    with connection() as c: return jsonify([dict(x) for x in c.execute('SELECT * FROM tasks ORDER BY id DESC')])

@app.patch('/api/tasks/<int:task_id>')
def update_task(task_id):
    status=(request.get_json(silent=True) or {}).get('status')
    if status not in ('Open','Approved','Rejected'): return jsonify(error='Invalid status.'),400
    with connection() as c:
        result=c.execute('UPDATE tasks SET status=? WHERE id=?',(status,task_id))
        if not result.rowcount: return jsonify(error='Task not found.'),404
    return jsonify(message='Task updated.')

if __name__=='__main__': app.run(debug=True)
