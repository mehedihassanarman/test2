from flask import Flask, render_template, request, jsonify, session
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
import secrets
import sqlite3, os
from datetime import datetime
app = Flask(__name__)
app.secret_key = os.environ.get('FLASK_SECRET_KEY', secrets.token_hex(32))
DB = os.path.join(os.path.dirname(__file__), 'materials.db')

def connection():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c

def init_db():
    with connection() as c:
        c.execute('CREATE TABLE IF NOT EXISTS materials (id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE NOT NULL, name TEXT NOT NULL, material_type TEXT NOT NULL, unit TEXT NOT NULL, plant TEXT NOT NULL, subsidiary TEXT NOT NULL, created_at TEXT NOT NULL)')
        c.execute('CREATE TABLE IF NOT EXISTS tasks (id INTEGER PRIMARY KEY AUTOINCREMENT, process_name TEXT NOT NULL, task_name TEXT NOT NULL, material_code TEXT NOT NULL, subsidiary TEXT NOT NULL, initiator TEXT NOT NULL, start_date TEXT NOT NULL, status TEXT NOT NULL DEFAULT "Open")')
        c.execute('CREATE TABLE IF NOT EXISTS articles (id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE NOT NULL, description TEXT NOT NULL, category TEXT NOT NULL, unit TEXT NOT NULL, subsidiary TEXT NOT NULL, created_at TEXT NOT NULL)')
        if 'article_code' not in [r[1] for r in c.execute('PRAGMA table_info(materials)')]:
            c.execute('ALTER TABLE materials ADD COLUMN article_code TEXT')
        c.execute('CREATE TABLE IF NOT EXISTS article_notifications (id INTEGER PRIMARY KEY AUTOINCREMENT, requester TEXT NOT NULL, subsidiary TEXT NOT NULL, description TEXT NOT NULL, status TEXT NOT NULL DEFAULT "Pending", article_code TEXT, created_at TEXT NOT NULL)')
        c.execute('CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, role TEXT NOT NULL)')
        for username, role in [('material','material'),('article','article'),('approver','approver')]:
            if not c.execute('SELECT 1 FROM users WHERE username=?',(username,)).fetchone():
                c.execute('INSERT INTO users (username,password_hash,role) VALUES (?,?,?)',(username,generate_password_hash(os.environ.get('DEMO_PASSWORD','ChangeMe123!')),role))
        c.execute('CREATE TABLE IF NOT EXISTS extensions (id INTEGER PRIMARY KEY AUTOINCREMENT, material_code TEXT NOT NULL, plant TEXT NOT NULL, subsidiary TEXT NOT NULL, created_at TEXT NOT NULL, UNIQUE(material_code, plant, subsidiary))')
init_db()

def current_user():
    if not session.get('uid'): return None
    with connection() as c:
        row=c.execute('SELECT id,username,role FROM users WHERE id=?',(session['uid'],)).fetchone()
        return dict(row) if row else None

def require(*roles):
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args,**kwargs):
            u=current_user()
            if not u: return jsonify(error='Login required'),401
            if roles and u['role'] not in roles: return jsonify(error='Not authorized for this action'),403
            return fn(*args,**kwargs)
        return wrapper
    return decorator

@app.post('/api/login')
def login():
    d=request.get_json(silent=True) or {}
    with connection() as c: u=c.execute('SELECT * FROM users WHERE username=?',(d.get('username'),)).fetchone()
    if not u or not check_password_hash(u['password_hash'],d.get('password','')): return jsonify(error='Invalid credentials'),401
    session.clear();session['uid']=u['id'];return jsonify(username=u['username'],role=u['role'])

@app.post('/api/logout')
def logout(): session.clear();return jsonify(message='Logged out')

@app.get('/api/me')
def me():
    u=current_user()
    return jsonify(u) if u else (jsonify(error='Login required'),401)

@app.get('/')
def home(): return render_template('index.html')

@app.get('/api/materials')
@require('material')
def materials():
    with connection() as c: return jsonify([dict(x) for x in c.execute('SELECT * FROM materials ORDER BY id DESC')])

@app.post('/api/materials')
@require('material')
def create_material():
    d=request.get_json(silent=True) or {}
    fields=['code','name','material_type','unit','plant','subsidiary','article_code']
    if any(not str(d.get(k,'')).strip() for k in fields): return jsonify(error='All fields are required.'),400
    try:
        with connection() as c:
            c.execute('BEGIN IMMEDIATE')
            article=c.execute('''SELECT a.code FROM articles a JOIN tasks t ON t.process_name='Article Creation' AND t.material_code=a.code WHERE a.code=? AND t.status='Approved' ''',(d['article_code'].strip(),)).fetchone()
            if not article: return jsonify(error='Select an approved 6-digit article code before creating a material.'),400
            c.execute('INSERT INTO materials (code,name,material_type,unit,plant,subsidiary,article_code,created_at) VALUES (?,?,?,?,?,?,?,?)',tuple(str(d[k]).strip() for k in fields)+(datetime.now().isoformat(timespec='seconds'),))
            c.execute('INSERT INTO tasks (process_name,task_name,material_code,subsidiary,initiator,start_date) VALUES (?,?,?,?,?,?)',('New Material','Review new material',d['code'].strip(),d['subsidiary'].strip(),current_user()['username'],datetime.now().strftime('%Y-%m-%d')))
        return jsonify(message='Material created successfully.'),201
    except sqlite3.IntegrityError: return jsonify(error='Material code already exists.'),409

@app.get('/api/articles')
@require('article')
def articles():
    with connection() as c:
        return jsonify([dict(x) for x in c.execute('SELECT * FROM articles ORDER BY id DESC')])

@app.get('/api/articles/approved')
@require('material')
def approved_articles():
    with connection() as c:
        return jsonify([dict(x) for x in c.execute("""SELECT a.code,a.description,a.category,a.unit,a.subsidiary FROM articles a WHERE EXISTS (SELECT 1 FROM tasks t WHERE t.process_name='Article Creation' AND t.material_code=a.code AND t.status='Approved') ORDER BY a.code""")])

@app.get('/api/article-notifications')
@require()
def article_notifications():
    with connection() as c:
        u=current_user()
        if u['role']=='material': rows=c.execute('SELECT * FROM article_notifications WHERE requester=? ORDER BY id DESC',(u['username'],))
        else: rows=c.execute('SELECT * FROM article_notifications ORDER BY id DESC')
        return jsonify([dict(r) for r in rows])

@app.post('/api/article-notifications')
@require('material')
def request_article_notification():
    d=request.get_json(silent=True) or {}
    if not str(d.get('description','')).strip() or not str(d.get('subsidiary','')).strip():
        return jsonify(error='Article description and subsidiary are required.'),400
    with connection() as c:
        cur=c.execute('INSERT INTO article_notifications (requester,subsidiary,description,created_at) VALUES (?,?,?,?)',
            (current_user()['username'],str(d['subsidiary']).strip(),str(d['description']).strip(),datetime.now().isoformat(timespec='seconds')))
    return jsonify(message='Notification sent to Article Creation. Await article approval.',notification_id=cur.lastrowid),201

@app.post('/api/articles')
@require('article')
def create_article():
    d=request.get_json(silent=True) or {}
    fields=['description','category','unit','subsidiary']
    if any(not isinstance(d.get(k),str) or not d[k].strip() for k in fields):
        return jsonify(error='All article fields are required.'),400
    notification_id=d.get('notification_id')
    with connection() as c:
        # BEGIN IMMEDIATE serializes concurrent code allocations across requests.
        c.execute('BEGIN IMMEDIATE')
        if notification_id:
            notification=c.execute('SELECT * FROM article_notifications WHERE id=? AND status="Pending"',(notification_id,)).fetchone()
            if not notification: return jsonify(error='Article notification not found or already processed.'),409
        last=c.execute('SELECT MAX(CAST(code AS INTEGER)) FROM articles').fetchone()[0]
        code_number=max(100000,last or 99999)+1
        if code_number>999999:
            return jsonify(error='Six-digit article code range exhausted.'),409
        code=str(code_number)
        now=datetime.now()
        c.execute('INSERT INTO articles (code,description,category,unit,subsidiary,created_at) VALUES (?,?,?,?,?,?)',
                  (code,*(d[k].strip() for k in fields),now.isoformat(timespec='seconds')))
        c.execute('INSERT INTO tasks (process_name,task_name,material_code,subsidiary,initiator,start_date) VALUES (?,?,?,?,?,?)',
                  ('Article Creation','Review article creation',code,d['subsidiary'].strip(),current_user()['username'],now.strftime('%Y-%m-%d')))
        if notification_id:
            c.execute('UPDATE article_notifications SET status="In Review",article_code=? WHERE id=?',(code,notification_id))
    return jsonify(message='Article creation request submitted.',article_code=code),201

@app.post('/api/extensions')
@require('material')
def extend_material():
    d=request.get_json(silent=True) or {}
    fields=['material_code','plant','subsidiary']
    if any(not str(d.get(k,'')).strip() for k in fields): return jsonify(error='All fields are required.'),400
    with connection() as c:
        if not c.execute('SELECT 1 FROM materials WHERE code=?',(d['material_code'].strip(),)).fetchone(): return jsonify(error='Material code not found.'),404
        try:
            c.execute('INSERT INTO extensions (material_code,plant,subsidiary,created_at) VALUES (?,?,?,?)',tuple(d[k].strip() for k in fields)+(datetime.now().isoformat(timespec='seconds'),))
            c.execute('INSERT INTO tasks (process_name,task_name,material_code,subsidiary,initiator,start_date) VALUES (?,?,?,?,?,?)',('Material Extension','Review extension',d['material_code'].strip(),d['subsidiary'].strip(),current_user()['username'],datetime.now().strftime('%Y-%m-%d')))
        except sqlite3.IntegrityError: return jsonify(error='This extension already exists.'),409
    return jsonify(message='Material extension requested.'),201

@app.get('/api/tasks')
@require()
def tasks():
    with connection() as c:
        u=current_user()
        if u['role']=='approver': rows=c.execute('SELECT * FROM tasks ORDER BY id DESC')
        else: rows=c.execute('SELECT * FROM tasks WHERE initiator=? OR process_name=? ORDER BY id DESC',(u['username'],'Article Creation' if u['role']=='article' else 'New Material'))
        return jsonify([dict(x) for x in rows])

@app.patch('/api/tasks/<int:task_id>')
@require('approver')
def update_task(task_id):
    status=(request.get_json(silent=True) or {}).get('status')
    if status not in ('Open','Approved','Rejected'): return jsonify(error='Invalid status.'),400
    with connection() as c:
        c.execute('BEGIN IMMEDIATE')
        existing=c.execute('SELECT status,process_name,material_code FROM tasks WHERE id=?',(task_id,)).fetchone()
        if existing and existing['status']!='Open': return jsonify(error='Only open tasks can be updated.'),409
        result=c.execute('UPDATE tasks SET status=? WHERE id=?',(status,task_id))
        if not result.rowcount: return jsonify(error='Task not found.'),404
        if existing['process_name']=='Article Creation' and status in ('Approved','Rejected'):
            c.execute('UPDATE article_notifications SET status=? WHERE article_code=? AND status="In Review"',('Ready for Material' if status=='Approved' else 'Rejected',existing['material_code']))
    return jsonify(message='Task updated.')

if __name__=='__main__': app.run(debug=True)
